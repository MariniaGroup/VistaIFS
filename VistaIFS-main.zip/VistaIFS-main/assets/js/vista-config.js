
/**
 * VistaIFS Site Config
 * Replace the placeholders below in Amplify (or edit this file and commit).
 * You can also set these as Amplify environment variables injected at build.
 */
window.VISTA_LEADS_WEBHOOK = "https://wh6hbh8w46.execute-api.us-west-2.amazonaws.com/dev/leads";
window.TIDIO_PUBLIC_KEY = "ypzxqwmfxijyvqpmejqbz3rpdh2gbouz";
